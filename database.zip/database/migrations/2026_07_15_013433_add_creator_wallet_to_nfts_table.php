<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('nfts', function (Blueprint $table) {
            $table->string('creator_wallet')->nullable()->after('wallet_address');
        });
    }
    public function down(): void
    {
        Schema::table('nfts', function (Blueprint $table) {
            $table->dropColumn('creator_wallet');
        });
    }
};
